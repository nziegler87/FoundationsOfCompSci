'''
    Nathanial Ziegler
    CS 5001
    Final Exam
    April 15, 2020
    Description:
        part1.py

    I pledge on my honor that I did not give or receive help on this exam.
'''

def divides(int1, int2):
    if int2 % int1 == 0:
        return True
    else:
        return False


def append(dictionary, key, value):
    if key in dictionary.keys():
        return dictionary
    else:
        dictionary[key] = value
        return dictionary

def more_efficient(string1, string2):
    efficiency_order = {"1":1, "lgn":2, "n":3, "nlgn":4, "nsquared":5}
    if efficiency_order[string1] < efficiency_order[string2]:
        return string1
    else:
        return string2

def stars(n):
    while not n:
        print("!!!")
        return
    else:
        print("*")
        stars(n-1)
